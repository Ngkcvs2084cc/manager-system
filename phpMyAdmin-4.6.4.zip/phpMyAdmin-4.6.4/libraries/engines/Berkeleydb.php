<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * The BerkeleyDB storage engine
 *
 * @package PhpMyAdmin-Engines
 */
namespace PMA\libraries\engines;

/**
 * This is same as BDB
 *
 * @package PhpMyAdmin-Engines
 */
class Berkeleydb extends Bdb
{
}

